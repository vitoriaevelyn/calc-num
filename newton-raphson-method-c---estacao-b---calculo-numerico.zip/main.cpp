/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include<stdio.h>
#include<math.h>
#include<stdlib.h>

/* Definindo a funcao */

#define    f(x)   392053.21481 * pow(x,5) - 9410548 * pow(x,2) - 188210960 * x - 941054800 


/* Definindo a funcao */

#define    g(x)   5*392053.21481*pow(x,4) - 2*9410548*x - 188210960 

int main()
{
	 float x0, x1, f0, f1, g0, e;
	 int iter = 1, N;



	 printf("\nDigite o valor inicial:\n");
	 scanf("%f", &x0);

	 printf("Digite a precisao:\n");
	 scanf("%f", &e);

	 printf("Digite o numero maximo de iteracoes:\n");
	 scanf("%d", &N);


	 /* Implementando o método de Newton-Raphson */


	 printf("\nPASSO\t\tx0\t\tf(x0)\t\tx1\t\tf(x1)\n");

	 do
	 {
		  g0 = g(x0);
		  f0 = f(x0);
		  if(g0 == 0.0)
		  {
			   printf("Erro - derivada nula no ponto %f",x0);
			   exit(0);
		  }

		
		  x1 = x0 - f0/g0;

		
		  printf("%d\t\t%f\t%f\t%f\t%f\n",iter,x0,f0,x1,f1);

		  x0 = x1;
		  
		  iter = iter+1;
		
		  if(iter > N)
		  {
			   printf("A sequencia nao convergiu apos maximo de iteracoes.");
			   exit(0);
		  }
		  
		  f1 = f(x1);
		  
	 }while(fabs(f1)>e);
	
	 printf("\nA raiz obtida eh: %f", x1);
}